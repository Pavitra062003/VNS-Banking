from django.contrib import admin
from django.urls import path
from accounts import views as acc_views
from dashboard import views as dash_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', acc_views.home, name='home'),
    path('create/', acc_views.create_account, name='create_account'),
    path('login/', acc_views.login_view, name='login'),
    path('dashboard/', dash_views.dashboard, name='dashboard'),
    path('dashboard/pdf/', dash_views.generate_pdf, name='generate_pdf'),

]