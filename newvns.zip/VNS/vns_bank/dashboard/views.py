from django.shortcuts import render
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa

from accounts.models import Customer
from dashboard.models import Account, Loan, Statement

def dashboard(request):
    customers = Customer.objects.all()
    accounts = Account.objects.all()
    loans = Loan.objects.all()
    statements = Statement.objects.all()

    context = {
        'customers': customers,
        'accounts': accounts,
        'loans': loans,
        'statements': statements,
    }
    return render(request, 'dashboard/dashboard.html', context)


def generate_pdf(request):
    customers = Customer.objects.all()
    accounts = Account.objects.all()
    loans = Loan.objects.all()
    statements = Statement.objects.all()

    template_path = 'dashboard/pdf_template.html'
    context = {
        'customers': customers,
        'accounts': accounts,
        'loans': loans,
        'statements': statements,
    }

    template = get_template(template_path)
    html = template.render(context)

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="dashboard_report.pdf"'

    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse('Error generating PDF <pre>' + html + '</pre>')
    return response