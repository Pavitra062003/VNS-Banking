from django.shortcuts import render, redirect
from .models import Customer
from .forms import CustomerForm
def home(request):
    return render(request, 'accounts/home.html')
def create_account(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomerForm()
    return render(request, 'accounts/create_account.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        login_id = request.POST.get('login_id')
        password = request.POST.get('password')
        try:
            customer = Customer.objects.get(login_id=login_id, password=password)
            return redirect('dashboard')
        except Customer.DoesNotExist:
            return render(request, 'accounts/login.html', {'error': 'Invalid credentials'})
    return render(request, 'accounts/login.html')