from django import forms
from .models import Customer

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = '__all__'
        widgets = {
            'gender': forms.RadioSelect(),
            'above_18': forms.CheckboxInput(),
        }