from django.db import models

class Query(models.Model):
    name = models.CharField(max_length=100)
    mobile_no = models.CharField(max_length=15)
    email = models.EmailField()
    query_text = models.TextField()